export interface DetalleHuellaDTO {
  id: number;
  usuario: string;
  correo: string;
  periodo: string;
  totalKgCO2: number;
  fechaCalculo: string;
  estado: string;
  categoria?: string;
  actividad?: string;
  consumosOriginales?: any[];
}
