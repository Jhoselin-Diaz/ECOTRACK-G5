import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-GUOLUKMF.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-LDYNV3LS.js";
import "./chunk-QIQIGXQK.js";
import "./chunk-QGXUTJ6Y.js";
import "./chunk-4EDVNTWX.js";
import "./chunk-L4L632M7.js";
import "./chunk-7XA6G6KX.js";
import "./chunk-S35MAB2V.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
